import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PromoComponent } from './promo/promo.component';
import { DisplaypromoComponent } from './displaypromo/displaypromo.component';


const routes: Routes = [
  {path: 'send', component: PromoComponent},
  {path: '' , redirectTo: '', pathMatch: 'full'},
  {path: 'display', component: DisplaypromoComponent}
 

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
