import { Injectable } from '@angular/core';
import { PromoModel } from './model/promo-model';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class PromoSerService {
  promoArray: PromoModel[] = [];
  constructor(private routes: Router) {
    this.promoArray = [];
  }
  addPromo(promo: PromoModel) {
    //promo.promoId = Math.floor(Math.random() * 100);
    this.promoArray.push(promo);
    // this.routes.navigate(['/displaypromo']);

  }
  sendPromo() {

    return this.promoArray;
  }

  send(promo: PromoModel) {
    this.promoArray.push(promo);
    alert("Promo send successfully");
    this.routes.navigate(['/display']);

  }
  display() {
    return this.promoArray;
  }
}
