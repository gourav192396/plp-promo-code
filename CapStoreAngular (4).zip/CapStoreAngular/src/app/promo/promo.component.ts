import { Component, OnInit, Input } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { PromoModel } from '../model/promo-model';

import {MatCardModule} from '@angular/material/card';
import { PromoSerService } from '../promo-ser.service';
@Component({
  selector: 'app-promo',
  templateUrl: './promo.component.html',
  styleUrls: ['./promo.component.css']
})

export class PromoComponent implements OnInit {
  email = new FormControl('', [Validators.required, Validators.email]);
  options: FormGroup;
  matCard: MatCardModule;

 // customerId = new FormControl('', [Validators.required, Validators.customerId]);

  @Input() promo: PromoModel;

  constructor(private routes: Router, fb: FormBuilder,private service: PromoSerService) {
    this.promo = new PromoModel();
    this.options = fb.group({
      color: 'primary',

    });

  }
  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter customer email' :
        this.email.hasError('email') ? 'Not a valid email' :
            '';
          }


  ngOnInit() {
  }
send(){
  this.service.send(this.promo);
}
}
