import { TestBed } from '@angular/core/testing';

import { PromoSerService } from './promo-ser.service';

describe('PromoSerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PromoSerService = TestBed.get(PromoSerService);
    expect(service).toBeTruthy();
  });
});
