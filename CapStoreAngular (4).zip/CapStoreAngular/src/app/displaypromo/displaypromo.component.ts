import { Component, OnInit } from '@angular/core';
import { PromoModel } from '../model/promo-model';
import { PromoSerService } from '../promo-ser.service';

@Component({
  selector: 'app-displaypromo',
  templateUrl: './displaypromo.component.html',
  styleUrls: ['./displaypromo.component.css']
})
export class DisplaypromoComponent implements OnInit {
promo: PromoModel;
promoarr: PromoModel[]=[];
  constructor( private service : PromoSerService) { }

  ngOnInit() {
    this.promoarr = this.service.display();
  }


}
