import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplaypromoComponent } from './displaypromo.component';

describe('DisplaypromoComponent', () => {
  let component: DisplaypromoComponent;
  let fixture: ComponentFixture<DisplaypromoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplaypromoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplaypromoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
