export class PromoModel {

    customerEmail: string;
    customerId: number;
    promoId: number;

}


