import { PromoModel } from './promo-model';

describe('PromoModel', () => {
  it('should create an instance', () => {
    expect(new PromoModel()).toBeTruthy();
  });
});
